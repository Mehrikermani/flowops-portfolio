# FlowOps Studio portfolio

Simple responsive static portfolio. No build tools required.

## Preview
Open `index.html` in a browser.

## Publish with Cloudflare Pages
1. Create a GitHub repository and upload `index.html`.
2. In Cloudflare, choose Workers & Pages > Create > Pages > Connect to Git.
3. Select the repository. Use no build command, and set output directory to `/` (repository root).
4. Deploy and use the generated pages.dev URL.
5. Add a custom domain later if desired.

## Before public business launch
- Replace placeholder LinkedIn link with your profile.
- Add a working contact method.
- Add legally appropriate Impressum and Datenschutzerklärung.
- Verify branding and domain availability.
- Replace project summaries with independently publishable demos and screenshots.
